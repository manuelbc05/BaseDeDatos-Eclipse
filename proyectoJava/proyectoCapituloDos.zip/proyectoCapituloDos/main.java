package proyectoCapituloDos;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;

import org.apache.ibatis.jdbc.ScriptRunner;

public class main {

	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		int opcion;

		do {
			System.out.println("=== Menú de creación de base de datos ===");
			System.out.println("1 -> Crear base de datos");
			System.out.println("2 -> Oracle SQL");
			System.out.println("3 -> Borrar ambas SQL");
			System.out.println("4 -> Salir");
			System.out.print("Selecciona una opción: ");
			opcion = scanner.nextInt();

			switch (opcion) {
			case 1:
				instalarMySQL();
				break;
			case 2:
				instalarOracle();
				break;
			case 3:
				eliminarAmbasSQL();
				break;
			case 4:
				
				System.out.println("Saliendo del programa...");
				break;
			default:
				System.out.println("Opción inválida. Intenta de nuevo.");
			}

			System.out.println(); // Línea en blanco para separar
		} while (opcion != 4);

		scanner.close();

	}

	public static void instalarMySQL() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/ejemplo?allowMultiQueries=true",
					"root", "");
			Reader reader = new FileReader("./script/accesoDatosmysql.sql");
			// Crear un objeto ScriptRunner
			ScriptRunner scriptRunner = new ScriptRunner(conexion);
			scriptRunner.setLogWriter(null); // Para que no muestre el
			scriptRunner.setAutoCommit(false); // Usar o no autocommit
			scriptRunner.runScript(reader); // ejecutar el script
			conexion.commit(); // confirmar los cambios
			System.out.println("Script ejecutado con éxito");
			conexion.close();
		} catch (ClassNotFoundException | IOException | java.sql.SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void instalarOracle() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conexion = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/XEPDB1", "EJEMPLO", "ejemplo");
			Reader reader = new FileReader("./script/accesoDatosoracle.sql");
			// Crear un objeto ScriptRunner
			ScriptRunner scriptRunner = new ScriptRunner(conexion);
			scriptRunner.setLogWriter(null); // Para que no muestre el
			scriptRunner.setAutoCommit(false); // Usar o no autocommit
			scriptRunner.runScript(reader); // ejecutar el script
			conexion.commit(); // confirmar los cambios
			System.out.println("Script ejecutado con éxito");
			conexion.close();
		} catch (ClassNotFoundException | IOException | java.sql.SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void eliminarAmbasSQL() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/ejemplo?allowMultiQueries=true",
					"root", "");
			Connection conexion2 = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/XEPDB1", "EJEMPLO", "ejemplo");
			Reader reader = new FileReader("./script/drop_all_mysql.sql");
			Reader reader2 = new FileReader("./script/drop_all_oracle.sql");
			// Crear un objeto ScriptRunner
			ScriptRunner scriptRunner = new ScriptRunner(conexion);
			ScriptRunner scriptRunner2 = new ScriptRunner(conexion2);
			scriptRunner.setLogWriter(null); // Para que no muestre el
			scriptRunner.setAutoCommit(false); // Usar o no autocommit
			scriptRunner.runScript(reader); // ejecutar el script
			scriptRunner2.setLogWriter(null); // Para que no muestre el
			scriptRunner2.setAutoCommit(false); // Usar o no autocommit
			scriptRunner2.runScript(reader); // ejecutar el script
			conexion.commit(); // confirmar los cambios
			conexion2.commit(); // confirmar los cambios
			System.out.println("Ambas SQL Borradas correctamente");
			conexion.close();
			conexion2.close();
		} catch (ClassNotFoundException | IOException | java.sql.SQLException e) {
			e.printStackTrace();
		}
	}
}